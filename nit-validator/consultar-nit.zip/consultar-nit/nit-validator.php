<?php
/**
 * Plugin Name: Validador de NIT para WooCommerce
 * Plugin URI: https://sushell.com/sat-plugin/
 * Description: Agrega un campo de validación de NIT en el carrito de compras de WooCommerce
 * Version: 0.0.6
 * Author: Multiservicios Sushell
 * Author URI: https://sushell.com/sat-plugin/
 * Text Domain: nit-validator
 * Domain Path: /languages
 * License: Private
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.5
 * 
 * @package NitValidator
 * @copyright 2024 Multiservicios Sushell
 * @license Private
 */

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Verificar versión mínima de PHP
if (version_compare(PHP_VERSION, '7.4', '<')) {
    add_action('admin_notices', function() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('El plugin Validador de NIT requiere PHP 7.4 o superior. Por favor actualice su versión de PHP.', 'nit-validator'); ?></p>
        </div>
        <?php
    });
    return;
}

// Verificar versión mínima de WordPress
if (version_compare(get_bloginfo('version'), '5.8', '<')) {
    add_action('admin_notices', function() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('El plugin Validador de NIT requiere WordPress 5.8 o superior. Por favor actualice WordPress.', 'nit-validator'); ?></p>
        </div>
        <?php
    });
    return;
}

// Verificar si WooCommerce está activo y en la versión correcta
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    add_action('admin_notices', function() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('El plugin Validador de NIT requiere que WooCommerce esté instalado y activado.', 'nit-validator'); ?></p>
        </div>
        <?php
    });
    return;
}

// Verificar versión mínima de WooCommerce
if (defined('WC_VERSION') && version_compare(WC_VERSION, '5.0', '<')) {
    add_action('admin_notices', function() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('El plugin Validador de NIT requiere WooCommerce 5.0 o superior. Por favor actualice WooCommerce.', 'nit-validator'); ?></p>
        </div>
        <?php
    });
    return;
}

// Definir constantes
define('NIT_VALIDATOR_VERSION', '0.0.6');
define('NIT_VALIDATOR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('NIT_VALIDATOR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('NIT_VALIDATOR_MIN_AMOUNT', 2500);

define('NIT_VALIDATOR_API_URL', 'https://sushell.com/wp-json/lmfwc/v2');
define('NIT_VALIDATOR_CONSUMER_KEY', 'ck_527503500539d7614a2dfa2f8c1263c268596367');
define('NIT_VALIDATOR_CONSUMER_SECRET', 'cs_5051afbf24fca9af15ce3ff5d558aee5b5a54ec3');

class LicenseManager {
    private static $instance = null;
    private $license_key = '';
    private $activation_token = '';
    private $license_status = false;
    private $license_data = array();

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->license_key = get_option('nit_validator_license_key', '');
        $this->activation_token = get_option('nit_validator_activation_token', '');
        $this->license_status = get_option('nit_validator_license_status', false);
        $this->license_data = get_option('nit_validator_license_data', array());

        add_action('admin_menu', array($this, 'add_license_menu'));
        add_action('admin_init', array($this, 'register_license_settings'));
        add_action('admin_notices', array($this, 'license_notice'));
    }

    public function add_license_menu() {
        add_submenu_page(
            'woocommerce',
            'Licencia NIT Validator',
            'Licencia NIT',
            'manage_options',
            'nit-validator-license',
            array($this, 'license_page')
        );
    }

    public function register_license_settings() {
        register_setting('nit_validator_license', 'nit_validator_license_key', array(
            'sanitize_callback' => 'sanitize_text_field'
        ));
    }

    public function license_page() {
        $license_key = get_option('nit_validator_license_key', '');
        $license_status = get_option('nit_validator_license_status', false);
        $license_data = get_option('nit_validator_license_data', array());
        
        // Procesar el formulario
        if (isset($_POST['nit_validator_license_key'])) {
            check_admin_referer('nit_validator_license_nonce');
            
            $new_license_key = sanitize_text_field($_POST['nit_validator_license_key']);
            
            if ($new_license_key !== $license_key) {
                // Nueva licencia ingresada
                update_option('nit_validator_license_key', $new_license_key);
                $license_key = $new_license_key;
                
                // Intentar activar la nueva licencia
                if ($this->activate_license()) {
                    add_settings_error('nit_validator_license', 'license_activated', __('Licencia activada correctamente.', 'nit-validator'), 'success');
                } else {
                    add_settings_error('nit_validator_license', 'license_activation_failed', __('Error al activar la licencia. La clave no es válida o no tiene activaciones disponibles.', 'nit-validator'), 'error');
                    // Si la activación falla, desactivamos la licencia
                    update_option('nit_validator_license_status', false);
                    update_option('nit_validator_license_data', array());
                }
            }
        }
        
        // Procesar desactivación
        if (isset($_POST['deactivate_license'])) {
            check_admin_referer('nit_validator_license_nonce');
            
            if ($this->deactivate_license()) {
                add_settings_error('nit_validator_license', 'license_deactivated', __('Licencia desactivada correctamente.', 'nit-validator'), 'success');
            } else {
                add_settings_error('nit_validator_license', 'license_deactivation_failed', __('Error al desactivar la licencia.', 'nit-validator'), 'error');
            }
        }
        
        // Mostrar mensajes de error/éxito
        settings_errors('nit_validator_license');
        ?>
        <div class="wrap">
            <h1><?php _e('Licencia NIT Validator', 'nit-validator'); ?></h1>
            
            <div class="card">
                <h2><?php _e('Estado de la Licencia', 'nit-validator'); ?></h2>
                <div class="license-status">
                    <?php if ($license_status): ?>
                        <div class="license-status-active">
                            <span class="dashicons dashicons-yes-alt"></span>
                            <?php _e('Licencia Activa', 'nit-validator'); ?>
                        </div>
                        <?php if (!empty($license_data)): ?>
                            <div class="license-details">
                                <p><strong><?php _e('Licencia:', 'nit-validator'); ?></strong> <?php echo esc_html($license_key); ?></p>
                                <p><strong><?php _e('Activaciones Restantes:', 'nit-validator'); ?></strong> 
                                    <span class="activation-count">
                                        <?php echo esc_html($license_data['remainingActivations']); ?> 
                                        de <?php echo esc_html($license_data['timesActivatedMax']); ?>
                                    </span>
                                </p>
                                <div class="activation-progress">
                                    <div class="progress-bar" style="width: <?php 
                                        $max_activations = intval($license_data['timesActivatedMax']);
                                        $remaining = intval($license_data['remainingActivations']);
                                        $used = $max_activations - $remaining;
                                        echo $max_activations > 0 ? ($used / $max_activations * 100) : 0;
                                    ?>%"></div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="license-status-inactive">
                            <span class="dashicons dashicons-warning"></span>
                            <?php _e('Licencia Inactiva', 'nit-validator'); ?>
                        </div>
                        <div class="license-details">
                            <p class="description"><?php _e('Para activar todas las funcionalidades del plugin, por favor ingrese su clave de licencia.', 'nit-validator'); ?></p>
                            <p class="description">
                                <a href="https://sushell.com/sat-plugin/" target="_blank" class="button button-primary">
                                    <?php _e('Comprar Nueva Licencia', 'nit-validator'); ?>
                                </a>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <h2><?php _e('Información de la Licencia', 'nit-validator'); ?></h2>
                <form method="post" action="">
                    <?php wp_nonce_field('nit_validator_license_nonce'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Clave de Licencia', 'nit-validator'); ?></th>
                            <td>
                                <input type="text" name="nit_validator_license_key" value="<?php echo esc_attr($license_key); ?>" class="regular-text">
                                <p class="description"><?php _e('Ingrese su clave de licencia para activar el plugin.', 'nit-validator'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(__('Guardar Licencia', 'nit-validator')); ?>
                </form>
            </div>

            <?php if ($license_status): ?>
            <div class="card">
                <h2><?php _e('Acciones de Licencia', 'nit-validator'); ?></h2>
                <form method="post" action="">
                    <?php wp_nonce_field('nit_validator_license_nonce'); ?>
                    <input type="hidden" name="deactivate_license" value="1">
                    <?php submit_button(__('Desactivar Licencia', 'nit-validator'), 'secondary', 'submit', false, array('onclick' => 'return confirm("¿Está seguro de que desea desactivar la licencia?");')); ?>
                </form>
            </div>
            <?php endif; ?>
        </div>

        <style>
            .card {
                background: #fff;
                border: 1px solid #ccd0d4;
                border-radius: 4px;
                margin-top: 20px;
                padding: 20px;
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
            }
            .license-status {
                margin: 20px 0;
                padding: 15px;
                border-radius: 4px;
            }
            .license-status-active {
                color: #46b450;
                font-size: 16px;
                font-weight: bold;
                padding: 10px;
                background: #f0f8f0;
                border-radius: 4px;
                margin-bottom: 15px;
            }
            .license-status-inactive {
                color: #dc3232;
                font-size: 16px;
                font-weight: bold;
                padding: 10px;
                background: #fef7f7;
                border-radius: 4px;
                margin-bottom: 15px;
            }
            .license-status .dashicons {
                font-size: 24px;
                width: 24px;
                height: 24px;
                margin-right: 10px;
                vertical-align: middle;
            }
            .license-details {
                margin-top: 15px;
                padding: 15px;
                background: #f8f9fa;
                border-radius: 4px;
            }
            .license-details p {
                margin: 10px 0;
            }
            .activation-count {
                font-weight: bold;
                color: #2271b1;
            }
            .activation-progress {
                height: 10px;
                background: #f0f0f1;
                border-radius: 5px;
                margin: 10px 0;
                overflow: hidden;
            }
            .progress-bar {
                height: 100%;
                background: #2271b1;
                transition: width 0.3s ease;
            }
            .form-table th {
                width: 200px;
            }
            .description {
                color: #666;
                font-style: italic;
                margin-top: 5px;
            }
            .notice {
                margin: 15px 0;
            }
            .notice p {
                margin: 0.5em 0;
                padding: 2px;
            }
            .button {
                margin-top: 5px;
            }
        </style>
        <?php
    }

    public function license_notice() {
        if (!$this->license_status) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p>
                    <strong><?php _e('NIT Validator - Licencia Inactiva', 'nit-validator'); ?></strong>
                    <br>
                    <?php _e('El plugin está desactivado. Por favor active su licencia para continuar.', 'nit-validator'); ?>
                    <a href="<?php echo admin_url('admin.php?page=nit-validator-license'); ?>" class="button button-primary" style="margin-left: 10px;">
                        <?php _e('Activar Licencia', 'nit-validator'); ?>
                    </a>
                </p>
            </div>
            <?php
        } else {
            ?>
            <div class="notice notice-success is-dismissible">
                <p>
                    <strong><?php _e('NIT Validator - Licencia Activa', 'nit-validator'); ?></strong>
                    <br>
                    <?php 
                    $license_data = get_option('nit_validator_license_data', array());
                    if (!empty($license_data)) {
                        printf(
                            __('Activaciones restantes: %d de %d', 'nit-validator'),
                            $license_data['remainingActivations'],
                            $license_data['timesActivatedMax']
                        );
                    }
                    ?>
                </p>
            </div>
            <?php
        }
    }

    public function validate_license() {
        if (empty($this->license_key)) {
            return false;
        }

        $response = wp_remote_get(
            NIT_VALIDATOR_API_URL . '/licenses/validate/' . $this->license_key,
            array(
                'headers' => array(
                    'Authorization' => 'Basic ' . base64_encode(NIT_VALIDATOR_CONSUMER_KEY . ':' . NIT_VALIDATOR_CONSUMER_SECRET),
                    'Accept' => 'application/json'
                ),
                'timeout' => 15
            )
        );

        if (is_wp_error($response)) {
            error_log('Error en validación de licencia: ' . $response->get_error_message());
            return false;
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        error_log('Respuesta de validación de licencia: ' . print_r($body, true));
        error_log('Código HTTP: ' . $http_code);

        // Verificar si la respuesta es válida y contiene los datos necesarios
        if ($http_code === 200 && 
            isset($body['success']) && 
            $body['success'] === true && 
            isset($body['data']) && 
            isset($body['data']['remainingActivations']) && 
            isset($body['data']['timesActivatedMax'])) {
            
            // Verificar que la licencia tenga activaciones disponibles
            if ($body['data']['remainingActivations'] > 0) {
                $this->license_status = true;
                $this->license_data = $body['data'];
                update_option('nit_validator_license_data', $this->license_data);
                update_option('nit_validator_license_status', true);
                return true;
            }
        }

        $this->license_status = false;
        update_option('nit_validator_license_status', false);
        return false;
    }

    public function activate_license() {
        if (empty($this->license_key)) {
            return false;
        }

        // Primero validamos la licencia
        $response = wp_remote_get(
            NIT_VALIDATOR_API_URL . '/licenses/validate/' . $this->license_key,
            array(
                'headers' => array(
                    'Authorization' => 'Basic ' . base64_encode(NIT_VALIDATOR_CONSUMER_KEY . ':' . NIT_VALIDATOR_CONSUMER_SECRET),
                    'Accept' => 'application/json'
                ),
                'timeout' => 15
            )
        );

        if (is_wp_error($response)) {
            error_log('Error en validación previa de licencia: ' . $response->get_error_message());
            return false;
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        // Verificar si la licencia es válida antes de intentar activarla
        if ($http_code !== 200 || 
            !isset($body['success']) || 
            $body['success'] !== true || 
            !isset($body['data']) || 
            !isset($body['data']['remainingActivations']) || 
            $body['data']['remainingActivations'] <= 0) {
            error_log('Licencia no válida o sin activaciones disponibles');
            return false;
        }

        // Si la licencia es válida, procedemos con la activación
        $response = wp_remote_get(
            NIT_VALIDATOR_API_URL . '/licenses/activate/' . $this->license_key,
            array(
                'headers' => array(
                    'Authorization' => 'Basic ' . base64_encode(NIT_VALIDATOR_CONSUMER_KEY . ':' . NIT_VALIDATOR_CONSUMER_SECRET),
                    'Accept' => 'application/json'
                ),
                'timeout' => 15
            )
        );

        if (is_wp_error($response)) {
            error_log('Error en activación de licencia: ' . $response->get_error_message());
            return false;
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        error_log('Respuesta de activación de licencia: ' . print_r($body, true));
        error_log('Código HTTP: ' . $http_code);

        if ($http_code === 200 && 
            isset($body['success']) && 
            $body['success'] === true && 
            isset($body['data'])) {
            
            $this->license_status = true;
            $this->license_data = $body['data'];
            update_option('nit_validator_license_data', $this->license_data);
            update_option('nit_validator_license_status', true);
            return true;
        }

        return false;
    }

    public function deactivate_license() {
        if (empty($this->license_key)) {
            return false;
        }

        $response = wp_remote_get(
            NIT_VALIDATOR_API_URL . '/licenses/deactivate/' . $this->license_key,
            array(
                'headers' => array(
                    'Authorization' => 'Basic ' . base64_encode(NIT_VALIDATOR_CONSUMER_KEY . ':' . NIT_VALIDATOR_CONSUMER_SECRET),
                    'Accept' => 'application/json'
                ),
                'timeout' => 15
            )
        );

        if (is_wp_error($response)) {
            error_log('Error en desactivación de licencia: ' . $response->get_error_message());
            return false;
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($http_code === 200 && isset($body['success']) && $body['success'] === true) {
            $this->license_status = false;
            $this->license_data = array();
            update_option('nit_validator_license_data', array());
            update_option('nit_validator_license_status', false);
            return true;
        }

        return false;
    }

    public function is_license_valid() {
        return $this->license_status;
    }
}

// Clase principal del plugin
class NitValidator {
    private static $instance = null;
    private $license_manager;
    private $basic_features = array(
        'validate_nit',
        'add_nit_field',
        'add_nit_checkout_field',
        'save_nit_order_meta',
        'display_nit_admin_order_meta'
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->license_manager = LicenseManager::get_instance();

        // Verificar si la licencia es válida antes de cargar las funcionalidades
        if (!$this->license_manager->is_license_valid()) {
            add_action('admin_notices', array($this, 'license_required_notice'));
            return;
        }

        // Cargar archivos de traducción
        add_action('plugins_loaded', array($this, 'load_textdomain'));

        // Agregar hooks principales
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('woocommerce_before_checkout_billing_form', array($this, 'add_nit_field'));
        add_action('wp_ajax_validate_nit', array($this, 'validate_nit'));
        add_action('wp_ajax_nopriv_validate_nit', array($this, 'validate_nit'));
        add_filter('woocommerce_checkout_fields', array($this, 'add_nit_checkout_field'));
        
        // Soporte para HPOS
        add_action('before_woocommerce_init', array($this, 'declare_hpos_compatibility'));
        
        // Mostrar en el panel de administración
        add_action('woocommerce_admin_order_data_after_billing_address', array($this, 'display_nit_admin_order_meta'));
        add_action('woocommerce_checkout_process', array($this, 'validate_checkout'));

        // Agregar soporte para temas
        add_action('after_setup_theme', array($this, 'add_theme_support'));

        // Agregar hooks para guardar datos del NIT
        add_action('woocommerce_checkout_update_order_meta', array($this, 'save_nit_order_meta'));
        add_action('woocommerce_process_shop_order_meta', array($this, 'save_nit_order_meta'));

        // Agregar hooks premium
        $this->add_premium_features();
    }

    private function add_premium_features() {
        // Agregar información de facturación a todos los correos
        add_action('woocommerce_email_order_meta', array($this, 'add_nit_to_emails'), 10, 3);
        add_action('woocommerce_email_customer_details', array($this, 'add_nit_to_emails'), 10, 3);
        add_action('woocommerce_email_admin_order_meta', array($this, 'add_nit_to_emails'), 10, 3);
    }

    public function license_required_notice() {
        ?>
        <div class="notice notice-error">
            <p>
                <?php _e('El plugin NIT Validator requiere una licencia válida para funcionar. Por favor active su licencia.', 'nit-validator'); ?>
                <a href="<?php echo admin_url('admin.php?page=nit-validator-license'); ?>" class="button button-primary" style="margin-left: 10px;">
                    <?php _e('Activar Licencia', 'nit-validator'); ?>
                </a>
                <a href="https://sushell.com/sat-plugin/" target="_blank" class="button button-secondary" style="margin-left: 10px;">
                    <?php _e('Comprar Licencia', 'nit-validator'); ?>
                </a>
            </p>
        </div>
        <?php
    }

    public function declare_hpos_compatibility() {
        if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        }
    }

    public function load_textdomain() {
        load_plugin_textdomain('nit-validator', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function add_theme_support() {
        // Agregar soporte para temas WooCommerce
        add_theme_support('woocommerce');
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');
    }

    public function enqueue_scripts() {
        if (is_checkout()) {
            // Registrar y encolar estilos
            wp_register_style(
                'nit-validator',
                NIT_VALIDATOR_PLUGIN_URL . 'assets/css/nit-validator.css',
                array(),
                NIT_VALIDATOR_VERSION
            );
            wp_enqueue_style('nit-validator');

            // Registrar y encolar scripts
            wp_register_script(
                'nit-validator',
                NIT_VALIDATOR_PLUGIN_URL . 'assets/js/nit-validator.js',
                array('jquery'),
                NIT_VALIDATOR_VERSION,
                true
            );
            wp_enqueue_script('nit-validator');

            // Localizar script
            wp_localize_script('nit-validator', 'nitValidator', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('validate_nit_nonce'),
                'i18n' => array(
                    'error' => __('Error al validar el NIT', 'nit-validator'),
                    'success' => __('NIT validado correctamente', 'nit-validator'),
                    'loading' => __('Validando NIT...', 'nit-validator'),
                    'required' => __('Por favor ingrese un NIT', 'nit-validator'),
                    'invalid' => __('NIT inválido', 'nit-validator')
                )
            ));
        }
    }

    public function add_nit_checkout_field($fields) {
        // Agregar campo oculto para el nombre a facturar
        $fields['billing']['billing_nit_name'] = array(
            'type'        => 'hidden',
            'label'       => 'Nombre a Facturar',
            'required'    => false,
            'class'       => array('form-row-wide'),
            'priority'    => 6,
        );

        return $fields;
    }

    public function add_nit_field() {
        // Obtener el total del carrito
        $cart = WC()->cart;
        $cart_total = 0;
        
        if ($cart) {
            $cart_total = $cart->get_cart_contents_total();
        }
        
        $is_required = $cart_total >= NIT_VALIDATOR_MIN_AMOUNT;
        ?>
        <div class="nit-validator-container" data-min-amount="<?php echo NIT_VALIDATOR_MIN_AMOUNT; ?>">
            <div class="nit-validator-form">
                <div class="form-group">
                    <label for="billing_nit"><?php echo $is_required ? 'NIT *' : 'NIT o CF'; ?></label>
                    <input type="text" name="billing_nit" id="billing_nit" class="input-text" 
                           placeholder="<?php echo $is_required ? 'Ingrese su NIT' : 'Ingrese NIT o CF'; ?>" 
                           <?php echo $is_required ? 'required' : ''; ?>>
                    <button type="button" id="validate-nit" class="button validate-nit">Validar NIT</button>
                </div>
                <div id="nit-result" class="nit-result"></div>
            </div>
            <div id="nit-billing-name" class="nit-billing-name" style="display: none;">
                <h4>Nombre a Facturar:</h4>
                <p id="nit-billing-name-value"></p>
            </div>
            <?php if (!$is_required): ?>
            <div class="nit-info">
                <p class="info-text">Para compras menores a Q<?php echo number_format(NIT_VALIDATOR_MIN_AMOUNT, 2); ?> puede usar CF (Consumidor Final)</p>
            </div>
            <?php endif; ?>
        </div>
        <style>
            .nit-validator-container {
                margin: 20px 0;
                padding: 15px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            .nit-validator-form {
                margin-bottom: 15px;
            }
            .form-group {
                display: flex;
                gap: 10px;
                align-items: center;
                margin-bottom: 10px;
            }
            .validate-nit {
                background-color: #731BD2;
                color: white;
                border: none;
                padding: 8px 15px;
                border-radius: 4px;
                cursor: pointer;
            }
            .validate-nit:hover {
                background-color: #620C87;
            }
            .validate-nit:disabled {
                background-color: #ccc;
                cursor: not-allowed;
            }
            .nit-result {
                margin-top: 10px;
            }
            .nit-result .success {
                color: #28a745;
                padding: 10px;
                background-color: #f8f9fa;
                border-radius: 4px;
            }
            .nit-result .error {
                color: #dc3545;
                padding: 10px;
                background-color: #f8f9fa;
                border-radius: 4px;
            }
            .nit-result .loading {
                color: #17a2b8;
                padding: 10px;
                background-color: #f8f9fa;
                border-radius: 4px;
            }
            .nit-billing-name {
                margin-top: 15px;
                padding: 10px;
                background-color: #f8f9fa;
                border-radius: 4px;
            }
            .nit-info {
                margin-top: 10px;
                padding: 10px;
                background-color: #e9ecef;
                border-radius: 4px;
            }
            .nit-info .info-text {
                color: #6c757d;
                margin: 0;
                font-size: 0.9em;
            }
        </style>
        <?php
    }

    private function login() {
        $ch = curl_init();
        
        // Primero obtenemos el token CSRF
        curl_setopt($ch, CURLOPT_URL, 'https://infile-facturas.feel.com.gt/users/sign_in');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language: es-US,es;q=0.9',
            'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
            'Origin: https://infile-facturas.feel.com.gt',
            'Referer: https://infile-facturas.feel.com.gt/users/sign_in'
        ));

        $response = curl_exec($ch);
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $body = substr($response, $header_size);
        
        // Extraer el token CSRF
        preg_match('/name="authenticity_token" value="([^"]+)"/', $body, $matches);
        if (!isset($matches[1])) {
            error_log('No se pudo obtener el token CSRF');
            return false;
        }
        $csrf_token = $matches[1];
        
        // Extraer las cookies iniciales
        preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $response, $matches);
        $cookies = array();
        foreach($matches[1] as $item) {
            parse_str($item, $cookie);
            $cookies = array_merge($cookies, $cookie);
        }
        $cookie_string = http_build_query($cookies, '', '; ');
        
        // Ahora hacemos el login
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array(
            'authenticity_token' => $csrf_token,
            'user[email]' => 'demofilapp@infile.com.gt',
            'user[password]' => 's$CyEr&Lnfp!^L9n',
            'commit' => 'Iniciar Sesión'
        )));
        curl_setopt($ch, CURLOPT_COOKIE, $cookie_string);
        curl_setopt($ch, CURLOPT_HEADER, true);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        error_log('Login HTTP Code: ' . $http_code);
        error_log('Login Response: ' . $response);
        
        if ($http_code !== 302) { // 302 es redirección después del login exitoso
            error_log('Error en login: ' . $http_code);
            return false;
        }
        
        // Extraer las cookies de sesión
        preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $response, $matches);
        $session_cookies = array();
        foreach($matches[1] as $item) {
            parse_str($item, $cookie);
            $session_cookies = array_merge($session_cookies, $cookie);
        }
        
        // Agregar la cookie efainfilebeta
        $session_cookies['efainfilebeta'] = '07e3660e39096030930028d4969be819';
        
        curl_close($ch);
        return http_build_query($session_cookies, '', '; ');
    }

    public function validate_nit() {
        check_ajax_referer('validate_nit_nonce', 'nonce');

        $nit = sanitize_text_field($_POST['nit']);
        
        if (empty($nit)) {
            wp_send_json_error('Por favor ingrese un NIT o CF');
            return;
        }

        // Si es CF, validar que el monto sea menor a 2500
        if (strtoupper($nit) === 'CF') {
            $cart = WC()->cart;
            $cart_total = 0;
            
            if ($cart) {
                $cart_total = $cart->get_cart_contents_total();
            }
            
            if ($cart_total >= NIT_VALIDATOR_MIN_AMOUNT) {
                wp_send_json_error('Para compras mayores a Q' . number_format(NIT_VALIDATOR_MIN_AMOUNT, 2) . ' debe ingresar un NIT válido');
                return;
            }
            
            wp_send_json_success(array(
                'data' => array(
                    'nit' => 'CF',
                    'nombre' => 'Consumidor Final'
                )
            ));
            return;
        }

        // Inicializar cURL
        $ch = curl_init();

        // Configurar cURL para el endpoint de Infile
        curl_setopt($ch, CURLOPT_URL, 'https://infile-facturas.feel.com.gt/facturas/nit?nit=' . urlencode($nit));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: application/json',
            'Accept-Language: es-US,es;q=0.9',
            'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
            'Origin: https://infile-facturas.feel.com.gt',
            'Referer: https://infile-facturas.feel.com.gt/',
            'Cookie: efainfilebeta=07e3660e39096030930028d4969be819'
        ));

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        error_log('URL: ' . curl_getinfo($ch, CURLINFO_EFFECTIVE_URL));
        error_log('HTTP Code: ' . $http_code);
        error_log('Response: ' . $response);
        
        curl_close($ch);

        if ($http_code === 401) {
            // Si recibimos 401, intentamos hacer login primero
            $session_cookies = $this->login();
            if (!$session_cookies) {
                wp_send_json_error('Error al autenticar con el servicio');
                return;
            }

            // Reintentamos la consulta con las cookies de sesión
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://infile-facturas.feel.com.gt/facturas/nit?nit=' . urlencode($nit));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Accept: application/json',
                'Accept-Language: es-US,es;q=0.9',
                'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
                'Origin: https://infile-facturas.feel.com.gt',
                'Referer: https://infile-facturas.feel.com.gt/',
                'Cookie: ' . $session_cookies
            ));

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            error_log('URL (segundo intento): ' . curl_getinfo($ch, CURLINFO_EFFECTIVE_URL));
            error_log('HTTP Code (segundo intento): ' . $http_code);
            error_log('Response (segundo intento): ' . $response);
            
            curl_close($ch);
        }

        if ($http_code !== 200) {
            wp_send_json_error('Error al consultar el NIT');
            return;
        }

        // Parsear la respuesta JSON
        $data = json_decode($response, true);
        if ($data === null) {
            error_log('Error al parsear JSON: ' . json_last_error_msg());
            wp_send_json_error('Error al procesar la respuesta del servicio');
            return;
        }

        if (!isset($data['resultado']) || !$data['resultado']) {
            wp_send_json_error('No se encontró información para el NIT proporcionado');
            return;
        }

        wp_send_json_success(array(
            'data' => array(
                'nit' => $data['descripcion']['nit'],
                'nombre' => $data['descripcion']['nombre']
            )
        ));
    }

    public function save_nit_order_meta($order_id) {
        // Obtener el NIT del campo del contenedor
        $nit = isset($_POST['billing_nit']) ? sanitize_text_field($_POST['billing_nit']) : '';
        if (!empty($nit)) {
            // Guardar usando el nuevo método de WooCommerce
            $order = wc_get_order($order_id);
            if ($order) {
                $order->update_meta_data('_billing_nit', $nit);
                $order->update_meta_data('_billing_nit_field', $nit);
            }
        }

        // Obtener el nombre del contribuyente
        $nit_name = isset($_POST['billing_nit_name']) ? sanitize_text_field($_POST['billing_nit_name']) : '';
        if (!empty($nit_name)) {
            // Guardar usando el nuevo método de WooCommerce
            $order = wc_get_order($order_id);
            if ($order) {
                $order->update_meta_data('_billing_nit_name', $nit_name);
                $order->update_meta_data('_billing_nit_name_field', $nit_name);
            }
        }
    }

    public function add_nit_to_emails($order, $sent_to_admin, $plain_text) {
        $nit = get_post_meta($order->get_id(), '_billing_nit', true);
        $nit_name = get_post_meta($order->get_id(), '_billing_nit_name', true);

        if ($nit) {
            if ($plain_text) {
                echo "\n\nInformación de Facturación\n";
                echo "------------------------\n";
                echo "NIT: " . esc_html($nit) . "\n";
                if ($nit_name) {
                    echo "Nombre a Facturar: " . esc_html($nit_name) . "\n";
                }
            } else {
                echo '<div style="margin-bottom: 40px;">';
                echo '<h2 style="color: #96588a; display: block; font-size: 18px; font-weight: bold; line-height: 130%; margin: 0 0 18px; text-transform: uppercase;">Información de Facturación</h2>';
                echo '<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif; margin-bottom: 40px;" border="1">';
                echo '<tbody>';
                echo '<tr>';
                echo '<th class="td" scope="row" style="text-align: left; vertical-align: middle; border: 1px solid #eee; font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif; word-wrap: break-word; color: #636363; padding: 12px;">NIT</th>';
                echo '<td class="td" style="text-align: left; vertical-align: middle; border: 1px solid #eee; font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif; word-wrap: break-word; color: #636363; padding: 12px;">' . esc_html($nit) . '</td>';
                echo '</tr>';
                if ($nit_name) {
                    echo '<tr>';
                    echo '<th class="td" scope="row" style="text-align: left; vertical-align: middle; border: 1px solid #eee; font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif; word-wrap: break-word; color: #636363; padding: 12px;">Nombre a Facturar</th>';
                    echo '<td class="td" style="text-align: left; vertical-align: middle; border: 1px solid #eee; font-family: \'Helvetica Neue\', Helvetica, Roboto, Arial, sans-serif; word-wrap: break-word; color: #636363; padding: 12px;">' . esc_html($nit_name) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
                echo '</div>';
            }
        }
    }

    public function display_nit_admin_order_meta($order) {
        // Obtener datos usando el nuevo método de WooCommerce
        $nit = $order->get_meta('_billing_nit');
        $nit_name = $order->get_meta('_billing_nit_name');

        if ($nit) {
            echo '<div class="nit-info-box" style="background: #f8f8f8; padding: 15px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px;">';
            echo '<h3 style="margin: 0 0 10px; color: #23282d; font-size: 14px; line-height: 1.4;">Información de Facturación</h3>';
            echo '<p style="margin: 0 0 5px;"><strong>NIT:</strong> ' . esc_html($nit) . '</p>';
            if ($nit_name) {
                echo '<p style="margin: 0;"><strong>Nombre a Facturar:</strong> ' . esc_html($nit_name) . '</p>';
            }
            echo '</div>';
        }
    }

    public function validate_checkout() {
        $cart = WC()->cart;
        $cart_total = 0;
        
        if ($cart) {
            $cart_total = $cart->get_cart_contents_total();
        }
        
        $nit = isset($_POST['billing_nit']) ? sanitize_text_field($_POST['billing_nit']) : '';
        
        if ($cart_total >= NIT_VALIDATOR_MIN_AMOUNT) {
            if (empty($nit)) {
                wc_add_notice('Por favor ingrese un NIT válido para compras mayores a Q' . number_format(NIT_VALIDATOR_MIN_AMOUNT, 2), 'error');
                return;
            }
            
            if (strtoupper($nit) === 'CF') {
                wc_add_notice('Para compras mayores a Q' . number_format(NIT_VALIDATOR_MIN_AMOUNT, 2) . ' debe ingresar un NIT válido', 'error');
                return;
            }
        }
    }
}

// Inicializar el plugin
function nit_validator_init() {
    // Inicializar el gestor de licencias
    LicenseManager::get_instance();
    
    // Inicializar el plugin principal
    NitValidator::get_instance();
}
add_action('plugins_loaded', 'nit_validator_init');

// Agregar enlace de configuración en la página de plugins
function nit_validator_plugin_action_links($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=nit-validator-license') . '">' . __('Licencia', 'nit-validator') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'nit_validator_plugin_action_links'); 