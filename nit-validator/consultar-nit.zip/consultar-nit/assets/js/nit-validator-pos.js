/**
 * Copyright (C) 2024 Fedired
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 * 
 * @version 0.0.6
 */

(function($) {
    'use strict';

    // Extender el modelo de registro de POS
    var RegisterModel = Backbone.Model.extend({
        initialize: function() {
            this.on('change:total', this.validateNitAmount, this);
        },

        validateNitAmount: function() {
            var total = this.get('total');
            var nit = this.get('billing_nit');
            
            if (total >= nitValidatorPos.minAmount && (!nit || nit.toUpperCase() === 'CF')) {
                this.trigger('nit_required');
            }
        }
    });

    // Extender la vista de registro de POS
    var RegisterView = Backbone.View.extend({
        initialize: function() {
            this.model.on('nit_required', this.showNitRequired, this);
            this.bindEvents();
        },

        bindEvents: function() {
            var self = this;
            this.$el.on('click', '.validate-nit-pos', function(e) {
                e.preventDefault();
                self.validateNit();
            });
        },

        validateNit: function() {
            var nit = this.$el.find('input[name="billing_nit"]').val().trim();
            var $result = this.$el.find('.nit-result-pos');
            var $button = this.$el.find('.validate-nit-pos');
            
            if (!nit) {
                $result.html('<p class="error">Por favor ingrese un NIT o CF</p>');
                return;
            }

            // Si es CF, validar localmente
            if (nit.toUpperCase() === 'CF') {
                var total = this.model.get('total');
                if (total >= nitValidatorPos.minAmount) {
                    $result.html(`<p class="error">Para compras mayores a Q${nitValidatorPos.minAmount.toFixed(2)} debe ingresar un NIT válido</p>`);
                    return;
                }

                $result.html(`
                    <div class="success">
                        <p><strong>NIT:</strong> CF</p>
                        <p><strong>Nombre:</strong> Consumidor Final</p>
                    </div>
                `);
                
                this.model.set({
                    'billing_nit': 'CF',
                    'billing_nit_name': 'Consumidor Final'
                });
                return;
            }

            // Deshabilitar el botón y mostrar mensaje de carga
            $button.prop('disabled', true);
            $result.html('<p class="loading">Validando NIT...</p>');

            // Realizar la petición AJAX
            $.ajax({
                url: nitValidatorPos.ajaxurl,
                type: 'POST',
                data: {
                    action: 'validate_nit',
                    nonce: nitValidatorPos.nonce,
                    nit: nit
                },
                success: function(response) {
                    if (response.success && response.data && response.data.data) {
                        const data = response.data.data;
                        $result.html(`
                            <div class="success">
                                <p><strong>NIT:</strong> ${data.nit}</p>
                                <p><strong>Nombre:</strong> ${data.nombre}</p>
                            </div>
                        `);
                        
                        self.model.set({
                            'billing_nit': data.nit,
                            'billing_nit_name': data.nombre
                        });
                    } else {
                        $result.html(`<p class="error">${response.data || 'Error al validar el NIT'}</p>`);
                        self.model.set({
                            'billing_nit': '',
                            'billing_nit_name': ''
                        });
                    }
                },
                error: function() {
                    $result.html('<p class="error">Error al validar el NIT. Por favor intente nuevamente.</p>');
                    self.model.set({
                        'billing_nit': '',
                        'billing_nit_name': ''
                    });
                },
                complete: function() {
                    $button.prop('disabled', false);
                }
            });
        },

        showNitRequired: function() {
            var $nitField = this.$el.find('input[name="billing_nit"]');
            if (!$nitField.val()) {
                this.$el.find('.nit-result-pos').html(
                    `<p class="error">Para compras mayores a Q${nitValidatorPos.minAmount.toFixed(2)} debe ingresar un NIT válido</p>`
                );
            }
        }
    });

    // Registrar la plantilla
    wp.templates.add('wc-pos-register-nit', `
        <div class="nit-validator-pos">
            <div class="form-group">
                <label for="billing_nit">NIT o CF</label>
                <input type="text" name="billing_nit" class="input-text" placeholder="Ingrese NIT o CF">
                <button type="button" class="button validate-nit-pos">Validar NIT</button>
            </div>
            <div class="nit-result-pos"></div>
        </div>
    `);

    // Inicializar cuando el DOM esté listo
    $(document).ready(function() {
        // Esperar a que el POS esté completamente cargado
        var checkPOS = setInterval(function() {
            if (typeof wc_pos !== 'undefined' && wc_pos.register) {
                clearInterval(checkPOS);
                
                var register = wc_pos.register;
                if (!register.model.hasOwnProperty('validateNitAmount')) {
                    register.model = new RegisterModel(register.model.attributes);
                    register.view = new RegisterView({
                        el: register.$el,
                        model: register.model
                    });
                }
            }
        }, 100);
    });

})(jQuery); 