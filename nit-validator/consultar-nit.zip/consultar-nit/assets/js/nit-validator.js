/**
 * Copyright (C) 2024 Fedired
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 * 
 * @version 0.0.5
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // Obtener el campo NIT del formulario de WooCommerce
        const $nitInput = $('input[name="billing_nit"]');
        const $nitNameInput = $('input[name="billing_nit_name"]');
        const $validateButton = $('#validate-nit');
        const $resultContainer = $('#nit-result');
        const $billingNameContainer = $('#nit-billing-name');
        const $billingNameValue = $('#nit-billing-name-value');
        const $container = $('.nit-validator-container');
        const minAmount = $container.data('min-amount') || 2500;

        // Asegurarse de que el botón existe
        if ($validateButton.length === 0) {
            console.error('El botón de validación de NIT no se encontró en el DOM');
            return;
        }

        // Asegurarse de que el campo NIT existe
        if ($nitInput.length === 0) {
            console.error('El campo NIT no se encontró en el formulario');
            return;
        }

        // Función para validar CF
        function validateCF(nit) {
            if (nit.toUpperCase() === 'CF') {
                // Obtener el total del carrito
                const cartTotal = parseFloat($('input[name="cart_total"]').val() || 0);
                
                if (cartTotal >= minAmount) {
                    $resultContainer.html(`<p class="error">Para compras mayores a Q${minAmount.toFixed(2)} debe ingresar un NIT válido</p>`);
                    return false;
                }

                $resultContainer.html(`
                    <div class="success">
                        <p><strong>NIT:</strong> CF</p>
                        <p><strong>Nombre:</strong> Consumidor Final</p>
                    </div>
                `);
                
                if ($nitNameInput.length > 0) {
                    $nitNameInput.val('Consumidor Final');
                }
                if ($billingNameValue.length > 0) {
                    $billingNameValue.text('Consumidor Final');
                    $billingNameContainer.show();
                }
                return true;
            }
            return false;
        }

        $validateButton.on('click', function(e) {
            e.preventDefault();
            
            const nit = $nitInput.val().trim();
            
            if (!nit) {
                $resultContainer.html('<p class="error">Por favor ingrese un NIT o CF</p>');
                return;
            }

            // Si es CF, validar localmente
            if (validateCF(nit)) {
                return;
            }

            // Deshabilitar el botón y mostrar mensaje de carga
            $validateButton.prop('disabled', true);
            $resultContainer.html('<p class="loading">Validando NIT...</p>');
            $billingNameContainer.hide();

            // Realizar la petición AJAX
            $.ajax({
                url: nitValidator.ajaxurl,
                type: 'POST',
                data: {
                    action: 'validate_nit',
                    nonce: nitValidator.nonce,
                    nit: nit
                },
                success: function(response) {
                    console.log('Respuesta del servidor:', response);
                    
                    if (response.success && response.data && response.data.data) {
                        const data = response.data.data;
                        $resultContainer.html(`
                            <div class="success">
                                <p><strong>NIT:</strong> ${data.nit}</p>
                                <p><strong>Nombre:</strong> ${data.nombre}</p>
                            </div>
                        `);
                        
                        // Actualizar el nombre a facturar
                        if ($nitNameInput.length > 0) {
                            $nitNameInput.val(data.nombre);
                        }
                        if ($billingNameValue.length > 0) {
                            $billingNameValue.text(data.nombre);
                            $billingNameContainer.show();
                        }
                    } else {
                        $resultContainer.html(`<p class="error">${response.data || 'Error al validar el NIT'}</p>`);
                        if ($nitNameInput.length > 0) {
                            $nitNameInput.val('');
                        }
                        $billingNameContainer.hide();
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error en la validación del NIT:', error);
                    $resultContainer.html(`<p class="error">Error al validar el NIT. Por favor intente nuevamente.</p>`);
                    if ($nitNameInput.length > 0) {
                        $nitNameInput.val('');
                    }
                    $billingNameContainer.hide();
                },
                complete: function() {
                    $validateButton.prop('disabled', false);
                }
            });
        });

        // Limpiar campos al cambiar el NIT
        $nitInput.on('change', function() {
            $resultContainer.empty();
            if ($nitNameInput.length > 0) {
                $nitNameInput.val('');
            }
            $billingNameContainer.hide();
        });
    });
})(jQuery); 